"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useTheme } from "next-themes"
import { useRouter } from "next/navigation"
import { Moon, Search, Settings, Sun, User, LogOut } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { PatientSummary } from "@/components/dashboard/patient-summary"
import { PatientVitals } from "@/components/dashboard/patient-vitals"

// Sample patient data for search
const patients = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    phone: "(555) 123-4567",
    symptoms: "Chest pain, shortness of breath",
    time: "10:00 AM",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 62,
    gender: "Male",
    phone: "(555) 234-5678",
    symptoms: "Joint pain, fever",
    time: "11:30 AM",
  },
  {
    id: 3,
    name: "Emily Davis",
    age: 28,
    gender: "Female",
    phone: "(555) 345-6789",
    symptoms: "Migraine, nausea",
    time: "2:15 PM",
  },
]

export function DashboardHeader() {
  const { setTheme, resolvedTheme } = useTheme()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [mounted, setMounted] = useState(false)

  // After mounting, we can safely show the UI that depends on the theme
  useEffect(() => {
    setMounted(true)
  }, [])

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value
    setSearchQuery(query)

    if (query.length > 2) {
      const results = patients.filter(
        (patient) => patient.name.toLowerCase().includes(query.toLowerCase()) || patient.phone.includes(query),
      )
      setSearchResults(results)
      setShowSearchResults(true)
    } else {
      setSearchResults([])
      setShowSearchResults(false)
    }
  }

  const handleSelectPatient = (patient: any) => {
    setShowSearchResults(false)
    // Navigate to patient details page
    router.push(`/dashboard/patients/${patient.id}`)
  }

  const handleLogout = () => {
    // Implement logout logic here
    router.push("/")
  }

  // Only show UI that depends on theme after mounting to prevent hydration mismatch
  if (!mounted) {
    return (
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-white px-4 md:px-6 shadow-sm">
        <div className="flex-1"></div>
      </header>
    )
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-white dark:bg-gray-800 dark:border-gray-700 px-4 md:px-6 shadow-sm">
      <div className="flex items-center gap-2">
        <Link href="/dashboard" className="flex items-center gap-2">
          <Image
            src="/healora-logo-horizontal.png"
            alt="HEALORA Logo"
            width={180}
            height={40}
            className="h-10 w-auto"
          />
        </Link>
      </div>

      <div className="flex-1 flex items-center relative">
        <form className="relative w-full max-w-md mx-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search patients by name or phone..."
            className="w-full pl-8 bg-gray-50/50 dark:bg-gray-700"
            value={searchQuery}
            onChange={handleSearch}
            onFocus={() => searchResults.length > 0 && setShowSearchResults(true)}
            onBlur={() => setTimeout(() => setShowSearchResults(false), 200)}
          />
          {showSearchResults && searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 shadow-lg rounded-md border border-gray-200 dark:border-gray-700 z-50">
              <ul className="py-1">
                {searchResults.map((patient) => (
                  <li
                    key={patient.id}
                    className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                    onMouseDown={() => handleSelectPatient(patient)}
                  >
                    <div className="flex justify-between">
                      <span className="font-medium">{patient.name}</span>
                      <span className="text-sm text-muted-foreground">{patient.phone}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {patient.age} years, {patient.gender}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </form>
      </div>

      <Dialog open={!!selectedPatient} onOpenChange={(open) => !open && setSelectedPatient(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Patient Information</DialogTitle>
            <DialogDescription>Detailed information about {selectedPatient?.name}</DialogDescription>
          </DialogHeader>
          {selectedPatient && (
            <div className="space-y-6">
              <PatientSummary patient={selectedPatient} />
              <PatientVitals patient={selectedPatient} />
            </div>
          )}
        </DialogContent>
      </Dialog>

      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 flex items-center gap-2 rounded-full pr-1.5">
              <div className="flex items-center gap-2">
                <Image src="/doctor-avatar.jpg" alt="Doctor Avatar" width={32} height={32} className="rounded-full" />
                <span className="font-medium text-sm hidden md:inline-block dark:text-gray-200">Dr. Smith</span>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <div className="flex items-center justify-start gap-2 p-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-100 dark:bg-gray-700">
                <User className="h-5 w-5 text-gray-700 dark:text-gray-300" />
              </div>
              <div className="flex flex-col space-y-0.5">
                <p className="text-sm font-medium">Dr. Smith</p>
                <p className="text-xs text-muted-foreground">Cardiologist</p>
              </div>
            </div>
            <DropdownMenuSeparator />

            {/* Profile option - redirects to doctor profile page */}
            <Link href="/dashboard/doctor-profile">
              <DropdownMenuItem className="cursor-pointer">
                <User className="mr-2 h-4 w-4" />
                <span>Profile</span>
              </DropdownMenuItem>
            </Link>

            {/* Settings submenu */}
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuSubTrigger>
              <DropdownMenuPortal>
                <DropdownMenuSubContent className="w-48">
                  <Link href="/dashboard/settings">
                    <DropdownMenuItem className="cursor-pointer">
                      <span>Change Password</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem
                    onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
                    className="cursor-pointer"
                  >
                    {resolvedTheme === "dark" ? (
                      <>
                        <Sun className="mr-2 h-4 w-4" />
                        <span>Light Mode</span>
                      </>
                    ) : (
                      <>
                        <Moon className="mr-2 h-4 w-4" />
                        <span>Dark Mode</span>
                      </>
                    )}
                  </DropdownMenuItem>
                </DropdownMenuSubContent>
              </DropdownMenuPortal>
            </DropdownMenuSub>

            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={handleLogout}
              className="cursor-pointer text-red-600 focus:text-red-600 dark:text-red-400 dark:focus:text-red-400"
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Logout</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

