import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export function UpcomingAppointments() {
  const appointments = [
    {
      id: 1,
      patient: "Sarah Johnson",
      time: "10:00 AM",
      type: "Check-up",
      status: "Confirmed",
      avatar: "SJ",
    },
    {
      id: 2,
      patient: "Michael Brown",
      time: "11:30 AM",
      type: "Follow-up",
      status: "Confirmed",
      avatar: "MB",
    },
    {
      id: 3,
      patient: "Emily Davis",
      time: "2:15 PM",
      type: "Consultation",
      status: "Pending",
      avatar: "ED",
    },
    {
      id: 4,
      patient: "Robert Wilson",
      time: "3:45 PM",
      type: "Check-up",
      status: "Confirmed",
      avatar: "RW",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upcoming Appointments</CardTitle>
        <CardDescription>You have {appointments.length} appointments today</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {appointments.map((appointment) => (
            <div key={appointment.id} className="flex items-center gap-4">
              <Avatar>
                <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${appointment.avatar}`} />
                <AvatarFallback>{appointment.avatar}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{appointment.patient}</p>
                  <Badge variant={appointment.status === "Confirmed" ? "default" : "outline"}>
                    {appointment.status}
                  </Badge>
                </div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <span>{appointment.time}</span>
                  <span className="mx-1">•</span>
                  <span>{appointment.type}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

