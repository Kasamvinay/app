"use client"

import { useState } from "react"
import { FileText, ClipboardList, Activity, Search, ChevronLeft, ChevronRight, Printer } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { PatientSummary } from "@/components/dashboard/patient-summary"
import { PrescriptionForm } from "@/components/dashboard/prescription-form"
import { PatientVitals } from "@/components/dashboard/patient-vitals"

// Sample patient data
const patients = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    symptoms: "Chest pain, shortness of breath",
    time: "10:00 AM",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 62,
    gender: "Male",
    symptoms: "Joint pain, fever",
    time: "11:30 AM",
  },
  {
    id: 3,
    name: "Emily Davis",
    age: 28,
    gender: "Female",
    symptoms: "Migraine, nausea",
    time: "2:15 PM",
  },
  {
    id: 4,
    name: "Robert Wilson",
    age: 54,
    gender: "Male",
    symptoms: "High blood pressure, dizziness",
    time: "3:45 PM",
  },
  {
    id: 5,
    name: "Jennifer Lee",
    age: 35,
    gender: "Female",
    symptoms: "Allergic reaction, skin rash",
    time: "4:30 PM",
  },
]

export function AllPatients() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)
  const [activeDialog, setActiveDialog] = useState<"summary" | "prescription" | "vitals" | null>(null)

  const filteredPatients = patients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.symptoms.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="border-gray-100 dark:border-gray-700 dark:bg-gray-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle>All Patients</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search patients..."
              className="pl-8 bg-gray-50/50 dark:bg-gray-700"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <CardDescription>Manage your patients and their appointments</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Age</TableHead>
              <TableHead>Gender</TableHead>
              <TableHead className="hidden md:table-cell">Symptoms</TableHead>
              <TableHead>Time</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPatients.map((patient) => (
              <TableRow key={patient.id} className="group">
                <TableCell className="font-medium">{patient.name}</TableCell>
                <TableCell>{patient.age}</TableCell>
                <TableCell>{patient.gender}</TableCell>
                <TableCell className="hidden md:table-cell max-w-[200px] truncate">{patient.symptoms}</TableCell>
                <TableCell>{patient.time}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/30"
                          onClick={() => {
                            setSelectedPatient(patient)
                            setActiveDialog("summary")
                          }}
                        >
                          <ClipboardList className="h-4 w-4" />
                          <span className="sr-only">Patient Summary</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Patient Summary</DialogTitle>
                          <DialogDescription>Detailed information about {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PatientSummary patient={selectedPatient} />}
                        <DialogFooter>
                          <Button variant="outline" onClick={() => window.print()} className="flex items-center gap-2">
                            <Printer className="h-4 w-4" />
                            Print Summary
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-green-600 dark:text-green-400 border-green-200 dark:border-green-800 hover:bg-green-50 dark:hover:bg-green-900/30"
                          onClick={() => {
                            setSelectedPatient(patient)
                            setActiveDialog("prescription")
                          }}
                        >
                          <FileText className="h-4 w-4" />
                          <span className="sr-only">Write Prescription</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl">
                        <DialogHeader>
                          <DialogTitle>Write Prescription</DialogTitle>
                          <DialogDescription>Create a prescription for {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PrescriptionForm patient={selectedPatient} />}
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800 hover:bg-red-50 dark:hover:bg-red-900/30"
                          onClick={() => {
                            setSelectedPatient(patient)
                            setActiveDialog("vitals")
                          }}
                        >
                          <Activity className="h-4 w-4" />
                          <span className="sr-only">Patient Vitals</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Patient Vitals</DialogTitle>
                          <DialogDescription>Current vital signs for {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PatientVitals patient={selectedPatient} />}
                      </DialogContent>
                    </Dialog>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {filteredPatients.map((patient) => (
          <div key={`vitals-${patient.id}`} className="mt-2 hidden group-hover:block">
            <PatientVitals patient={patient} />
          </div>
        ))}
      </CardContent>
      <CardFooter className="flex items-center justify-between border-t p-4 dark:border-gray-700">
        <div className="text-sm text-muted-foreground">
          Showing {filteredPatients.length} of {patients.length} patients
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Previous page</span>
          </Button>
          <Button variant="outline" size="sm" className="h-8 w-8 p-0">
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Next page</span>
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

