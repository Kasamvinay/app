import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface PatientSummaryProps {
  patient: {
    id: number
    name: string
    age: number
    gender: string
    symptoms: string
    time: string
  }
}

export function PatientSummary({ patient }: PatientSummaryProps) {
  // Sample data for patient details
  const patientDetails = {
    bloodGroup: "O+",
    height: "175 cm",
    weight: "68 kg",
    allergies: "Penicillin",
    emergencyContact: "John Johnson (Spouse) - (555) 123-4567",
    address: "123 Main St, Anytown, USA",
    insurance: "MedCare Health Insurance",
    policyNumber: "MC-12345678",
  }

  // Sample data for current visit
  const currentVisit = {
    date: "April 3, 2025",
    chiefComplaint: patient.symptoms,
    diagnosis: "Hypertension, Anxiety",
    treatment: "Prescribed medication, Recommended lifestyle changes",
    followUp: "2 weeks",
  }

  // Sample data for lab reports
  const currentLabReports = [
    { test: "Complete Blood Count", result: "Normal", date: "April 3, 2025" },
    { test: "Blood Pressure", result: "140/90 mmHg (Elevated)", date: "April 3, 2025" },
    { test: "Blood Glucose", result: "110 mg/dL (Normal)", date: "April 3, 2025" },
  ]

  // Sample data for past visits
  const pastVisits = [
    {
      date: "March 15, 2025",
      reason: "Annual check-up",
      diagnosis: "Healthy, mild hypertension",
      doctor: "Dr. Smith",
      labReports: [
        { test: "Complete Blood Count", result: "Normal", date: "March 15, 2025" },
        { test: "Blood Pressure", result: "135/85 mmHg (Slightly Elevated)", date: "March 15, 2025" },
      ],
    },
    {
      date: "January 10, 2025",
      reason: "Flu symptoms",
      diagnosis: "Seasonal influenza",
      doctor: "Dr. Johnson",
      labReports: [
        { test: "Influenza Test", result: "Positive for Influenza A", date: "January 10, 2025" },
        { test: "Chest X-ray", result: "Clear, no pneumonia", date: "January 10, 2025" },
      ],
    },
  ]

  return (
    <div className="space-y-6 py-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Patient Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Name</p>
                <p>{patient.name}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Patient ID</p>
                <p>PT-{patient.id.toString().padStart(6, "0")}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Age</p>
                <p>{patient.age} years</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Gender</p>
                <p>{patient.gender}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Blood Group</p>
                <p>{patientDetails.bloodGroup}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Height/Weight</p>
                <p>
                  {patientDetails.height} / {patientDetails.weight}
                </p>
              </div>
              <div className="space-y-1 col-span-2">
                <p className="text-sm font-medium text-muted-foreground">Allergies</p>
                <p>{patientDetails.allergies}</p>
              </div>
              <div className="space-y-1 col-span-2">
                <p className="text-sm font-medium text-muted-foreground">Emergency Contact</p>
                <p>{patientDetails.emergencyContact}</p>
              </div>
              <div className="space-y-1 col-span-2">
                <p className="text-sm font-medium text-muted-foreground">Address</p>
                <p>{patientDetails.address}</p>
              </div>
              <div className="space-y-1 col-span-2">
                <p className="text-sm font-medium text-muted-foreground">Insurance</p>
                <p>
                  {patientDetails.insurance} (Policy: {patientDetails.policyNumber})
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Current Visit Details</CardTitle>
            <CardDescription>Visit on {currentVisit.date}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Chief Complaint</p>
                <p>{currentVisit.chiefComplaint}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Diagnosis</p>
                <div className="flex flex-wrap gap-2">
                  {currentVisit.diagnosis.split(", ").map((diagnosis, index) => (
                    <Badge key={index} variant="outline" className="bg-blue-50">
                      {diagnosis}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Treatment Plan</p>
                <p>{currentVisit.treatment}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Follow-up</p>
                <p>{currentVisit.followUp}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="current-lab" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="current-lab">Current Lab Reports</TabsTrigger>
          <TabsTrigger value="past-visits">Past Visits & Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="current-lab" className="border rounded-md mt-4 p-4">
          <h3 className="text-lg font-medium mb-4">Lab Reports ({currentVisit.date})</h3>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Test</TableHead>
                <TableHead>Result</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentLabReports.map((report, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{report.test}</TableCell>
                  <TableCell>{report.result}</TableCell>
                  <TableCell>{report.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>

        <TabsContent value="past-visits" className="border rounded-md mt-4 p-4">
          <h3 className="text-lg font-medium mb-4">Past Visits</h3>
          <div className="space-y-6">
            {pastVisits.map((visit, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-base">{visit.date}</CardTitle>
                    <Badge variant="outline">{visit.doctor}</Badge>
                  </div>
                  <CardDescription>{visit.reason}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-muted-foreground">Diagnosis</p>
                      <p>{visit.diagnosis}</p>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">Lab Reports</p>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Test</TableHead>
                            <TableHead>Result</TableHead>
                            <TableHead>Date</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {visit.labReports.map((report, reportIndex) => (
                            <TableRow key={reportIndex}>
                              <TableCell className="font-medium">{report.test}</TableCell>
                              <TableCell>{report.result}</TableCell>
                              <TableCell>{report.date}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

