interface PatientVitalsProps {
  patient: {
    id: number
    name: string
    age: number
    gender: string
  }
}

export function PatientVitals({ patient }: PatientVitalsProps) {
  // Sample vitals data - in a real app, this would come from your database
  const vitals = {
    heartRate: {
      current: 75,
      unit: "bpm",
      status: "normal", // normal, elevated, low
      range: "60-100 bpm",
      lastUpdated: "10 minutes ago",
    },
    bloodPressure: {
      current: "120/80",
      unit: "mmHg",
      status: "normal", // normal, elevated, high
      range: "< 120/80 mmHg",
      lastUpdated: "10 minutes ago",
    },
    temperature: {
      current: 37.5,
      unit: "°C",
      status: "normal", // normal, elevated, low
      range: "36.5-37.5 °C",
      lastUpdated: "10 minutes ago",
    },
    oxygenSaturation: {
      current: 98,
      unit: "%",
      status: "normal", // normal, low
      range: "> 95%",
      lastUpdated: "10 minutes ago",
    },
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal":
        return "text-green-600 dark:text-green-400"
      case "elevated":
        return "text-amber-600 dark:text-amber-400"
      case "high":
        return "text-red-600 dark:text-red-400"
      case "low":
        return "text-blue-600 dark:text-blue-400"
      default:
        return "text-gray-600 dark:text-gray-400"
    }
  }

  return (
    <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-lg">
      <div className="grid grid-cols-4 gap-4">
        <div className="space-y-1">
          <div className="text-sm text-gray-500 dark:text-gray-400">Heart Rate</div>
          <div className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {vitals.heartRate.current} <span className="text-sm font-normal">{vitals.heartRate.unit}</span>
          </div>
        </div>

        <div className="space-y-1">
          <div className="text-sm text-gray-500 dark:text-gray-400">Blood Pressure</div>
          <div className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {vitals.bloodPressure.current} <span className="text-sm font-normal">{vitals.bloodPressure.unit}</span>
          </div>
        </div>

        <div className="space-y-1">
          <div className="text-sm text-gray-500 dark:text-gray-400">Temperature</div>
          <div className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {vitals.temperature.current} <span className="text-sm font-normal">{vitals.temperature.unit}</span>
          </div>
        </div>

        <div className="space-y-1">
          <div className="text-sm text-gray-500 dark:text-gray-400">Oxygen Saturation</div>
          <div className="text-xl font-semibold text-gray-900 dark:text-gray-100">
            {vitals.oxygenSaturation.current}
            <span className="text-sm font-normal">{vitals.oxygenSaturation.unit}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

