"use client"

import type React from "react"

import { useState } from "react"
import { X, Plus, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"

interface PrescriptionFormProps {
  patient: {
    id: number
    name: string
    age: number
    gender: string
    symptoms: string
  }
}

interface Medicine {
  id: number
  name: string
  dosage: string
  frequency: string
}

export function PrescriptionForm({ patient }: PrescriptionFormProps) {
  const [medicines, setMedicines] = useState<Medicine[]>([{ id: 1, name: "", dosage: "", frequency: "" }])
  const [comments, setComments] = useState("")
  const [followUpDate, setFollowUpDate] = useState<Date | undefined>(undefined)

  const addMedicine = () => {
    const newId = medicines.length > 0 ? Math.max(...medicines.map((m) => m.id)) + 1 : 1
    setMedicines([...medicines, { id: newId, name: "", dosage: "", frequency: "" }])
  }

  const removeMedicine = (id: number) => {
    if (medicines.length > 1) {
      setMedicines(medicines.filter((medicine) => medicine.id !== id))
    }
  }

  const updateMedicine = (id: number, field: keyof Medicine, value: string) => {
    setMedicines(medicines.map((medicine) => (medicine.id === id ? { ...medicine, [field]: value } : medicine)))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle prescription submission
    console.log({
      patient,
      medicines,
      comments,
      followUpDate,
    })
    // Close dialog or show success message
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 py-4">
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-lg font-medium">Patient: {patient.name}</h3>
            <p className="text-sm text-muted-foreground">
              {patient.age} years, {patient.gender}
            </p>
          </div>
          <div className="text-sm text-muted-foreground">Date: {format(new Date(), "MMMM d, yyyy")}</div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-base font-medium">Medicines</h3>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addMedicine}
            className="flex items-center gap-1 text-blue-600"
          >
            <Plus className="h-4 w-4" />
            Add Medicine
          </Button>
        </div>

        {medicines.map((medicine, index) => (
          <div key={medicine.id} className="grid grid-cols-12 gap-4 items-start">
            <div className="col-span-5">
              <Label htmlFor={`medicine-name-${medicine.id}`}>Medicine Name</Label>
              <Input
                id={`medicine-name-${medicine.id}`}
                value={medicine.name}
                onChange={(e) => updateMedicine(medicine.id, "name", e.target.value)}
                placeholder="e.g., Amoxicillin"
                className="mt-1"
              />
            </div>
            <div className="col-span-3">
              <Label htmlFor={`medicine-dosage-${medicine.id}`}>Dosage</Label>
              <Input
                id={`medicine-dosage-${medicine.id}`}
                value={medicine.dosage}
                onChange={(e) => updateMedicine(medicine.id, "dosage", e.target.value)}
                placeholder="e.g., 500mg"
                className="mt-1"
              />
            </div>
            <div className="col-span-3">
              <Label htmlFor={`medicine-frequency-${medicine.id}`}>Frequency</Label>
              <Select
                value={medicine.frequency}
                onValueChange={(value) => updateMedicine(medicine.id, "frequency", value)}
              >
                <SelectTrigger id={`medicine-frequency-${medicine.id}`} className="mt-1">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="once-daily">Once Daily</SelectItem>
                  <SelectItem value="twice-daily">Twice Daily</SelectItem>
                  <SelectItem value="thrice-daily">Three Times Daily</SelectItem>
                  <SelectItem value="four-times-daily">Four Times Daily</SelectItem>
                  <SelectItem value="as-needed">As Needed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-1 flex items-end justify-end">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => removeMedicine(medicine.id)}
                className="h-10 w-10 mt-1 text-red-500 hover:text-red-600 hover:bg-red-50"
                disabled={medicines.length <= 1}
              >
                <X className="h-4 w-4" />
                <span className="sr-only">Remove medicine</span>
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <Label htmlFor="comments">Doctor's Comments</Label>
        <Textarea
          id="comments"
          value={comments}
          onChange={(e) => setComments(e.target.value)}
          placeholder="Add any additional instructions or comments..."
          className="min-h-[100px]"
        />
      </div>

      <div className="space-y-2">
        <Label>Follow-up Appointment</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start text-left font-normal">
              <Calendar className="mr-2 h-4 w-4" />
              {followUpDate ? format(followUpDate, "PPP") : <span>Select a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <CalendarComponent
              mode="single"
              selected={followUpDate}
              onSelect={setFollowUpDate}
              initialFocus
              disabled={(date) => date < new Date()}
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline">
          Cancel
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
          Save Prescription
        </Button>
      </div>
    </form>
  )
}

