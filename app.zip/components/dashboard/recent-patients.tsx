"use client"

import { useState } from "react"
import { FileText, ClipboardList, Activity, Search, Clock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { PatientSummary } from "@/components/dashboard/patient-summary"
import { PrescriptionForm } from "@/components/dashboard/prescription-form"
import { PatientVitals } from "@/components/dashboard/patient-vitals"

// Sample recent patient data
const recentPatients = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    symptoms: "Chest pain, shortness of breath",
    time: "Today, 10:00 AM",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 62,
    gender: "Male",
    symptoms: "Joint pain, fever",
    time: "Today, 11:30 AM",
  },
  {
    id: 3,
    name: "Emily Davis",
    age: 28,
    gender: "Female",
    symptoms: "Migraine, nausea",
    time: "Yesterday, 2:15 PM",
  },
]

export function RecentPatients() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPatient, setSelectedPatient] = useState<any>(null)

  const filteredPatients = recentPatients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patient.symptoms.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="border-blue-100">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle>Recent Patients</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="relative w-64">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search recent patients..."
              className="pl-8 bg-blue-50/50"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
        <CardDescription>Your most recently seen patients</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Age</TableHead>
              <TableHead>Gender</TableHead>
              <TableHead className="hidden md:table-cell">Symptoms</TableHead>
              <TableHead>Time</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPatients.map((patient) => (
              <TableRow key={patient.id}>
                <TableCell className="font-medium">{patient.name}</TableCell>
                <TableCell>{patient.age}</TableCell>
                <TableCell>{patient.gender}</TableCell>
                <TableCell className="hidden md:table-cell max-w-[200px] truncate">{patient.symptoms}</TableCell>
                <TableCell>{patient.time}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-blue-600"
                          onClick={() => setSelectedPatient(patient)}
                        >
                          <ClipboardList className="h-4 w-4" />
                          <span className="sr-only">Patient Summary</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Patient Summary</DialogTitle>
                          <DialogDescription>Detailed information about {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PatientSummary patient={selectedPatient} />}
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-green-600"
                          onClick={() => setSelectedPatient(patient)}
                        >
                          <FileText className="h-4 w-4" />
                          <span className="sr-only">Write Prescription</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-3xl">
                        <DialogHeader>
                          <DialogTitle>Write Prescription</DialogTitle>
                          <DialogDescription>Create a prescription for {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PrescriptionForm patient={selectedPatient} />}
                      </DialogContent>
                    </Dialog>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 text-red-600"
                          onClick={() => setSelectedPatient(patient)}
                        >
                          <Activity className="h-4 w-4" />
                          <span className="sr-only">Patient Vitals</span>
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Patient Vitals</DialogTitle>
                          <DialogDescription>Current vital signs for {selectedPatient?.name}</DialogDescription>
                        </DialogHeader>
                        {selectedPatient && <PatientVitals patient={selectedPatient} />}
                      </DialogContent>
                    </Dialog>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

