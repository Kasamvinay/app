"use client"

import type React from "react"

import { useState } from "react"
import { Search, Plus, ChevronLeft, ChevronRight } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

// Sample nurses data
const nurses = [
  {
    id: 1,
    name: "Jennifer Wilson",
    email: "jennifer.wilson@hospital.com",
    phone: "(555) 123-4567",
    specialization: "Emergency Care",
    experience: "8 years",
    status: "On Duty",
  },
  {
    id: 2,
    name: "Robert Garcia",
    email: "robert.garcia@hospital.com",
    phone: "(555) 234-5678",
    specialization: "Pediatric Care",
    experience: "5 years",
    status: "On Duty",
  },
  {
    id: 3,
    name: "Lisa Thompson",
    email: "lisa.thompson@hospital.com",
    phone: "(555) 345-6789",
    specialization: "Surgical Care",
    experience: "10 years",
    status: "On Leave",
  },
  {
    id: 4,
    name: "David Martinez",
    email: "david.martinez@hospital.com",
    phone: "(555) 456-7890",
    specialization: "Intensive Care",
    experience: "7 years",
    status: "On Duty",
  },
]

export function AllNurses() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddNurseOpen, setIsAddNurseOpen] = useState(false)

  const filteredNurses = nurses.filter(
    (nurse) =>
      nurse.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      nurse.specialization.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <>
      <Card className="border-blue-100">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>All Nurses</CardTitle>
            <div className="flex items-center gap-2">
              <div className="relative w-64">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search nurses..."
                  className="pl-8 bg-blue-50/50"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Dialog open={isAddNurseOpen} onOpenChange={setIsAddNurseOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Nurse
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add New Nurse</DialogTitle>
                    <DialogDescription>Enter the details of the new nurse to add them to the system.</DialogDescription>
                  </DialogHeader>
                  <AddNurseForm onClose={() => setIsAddNurseOpen(false)} />
                </DialogContent>
              </Dialog>
            </div>
          </div>
          <CardDescription>Manage nursing staff and their assignments</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead className="hidden md:table-cell">Email</TableHead>
                <TableHead className="hidden md:table-cell">Phone</TableHead>
                <TableHead>Specialization</TableHead>
                <TableHead>Experience</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredNurses.map((nurse) => (
                <TableRow key={nurse.id}>
                  <TableCell className="font-medium">{nurse.name}</TableCell>
                  <TableCell className="hidden md:table-cell">{nurse.email}</TableCell>
                  <TableCell className="hidden md:table-cell">{nurse.phone}</TableCell>
                  <TableCell>{nurse.specialization}</TableCell>
                  <TableCell>{nurse.experience}</TableCell>
                  <TableCell>
                    <Badge
                      variant={nurse.status === "On Duty" ? "default" : "outline"}
                      className={
                        nurse.status === "On Duty"
                          ? "bg-green-100 text-green-800 hover:bg-green-100"
                          : "bg-red-100 text-red-800 hover:bg-red-100"
                      }
                    >
                      {nurse.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex items-center justify-between border-t p-4">
          <div className="text-sm text-muted-foreground">
            Showing {filteredNurses.length} of {nurses.length} nurses
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="h-8 w-8 p-0">
              <ChevronLeft className="h-4 w-4" />
              <span className="sr-only">Previous page</span>
            </Button>
            <Button variant="outline" size="sm" className="h-8 w-8 p-0">
              <ChevronRight className="h-4 w-4" />
              <span className="sr-only">Next page</span>
            </Button>
          </div>
        </CardFooter>
      </Card>
    </>
  )
}

function AddNurseForm({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    specialization: "",
    experience: "",
    address: "",
    emergencyContact: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log(formData)
    onClose()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 py-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Full Name</Label>
          <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Phone Number</Label>
          <Input id="phone" name="phone" value={formData.phone} onChange={handleChange} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="specialization">Specialization</Label>
          <Input
            id="specialization"
            name="specialization"
            value={formData.specialization}
            onChange={handleChange}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="experience">Experience</Label>
          <Input
            id="experience"
            name="experience"
            value={formData.experience}
            onChange={handleChange}
            placeholder="e.g., 5 years"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="emergencyContact">Emergency Contact</Label>
          <Input
            id="emergencyContact"
            name="emergencyContact"
            value={formData.emergencyContact}
            onChange={handleChange}
            placeholder="Name and phone number"
            required
          />
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="address">Address</Label>
        <Textarea id="address" name="address" value={formData.address} onChange={handleChange} required />
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
          Add Nurse
        </Button>
      </DialogFooter>
    </form>
  )
}

