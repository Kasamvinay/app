import { redirect } from "next/navigation"
import { LoginForm } from "@/components/login-form"
import { ThemeProvider } from "@/components/theme-provider"

export default function Home() {
  // This would be replaced with actual auth check
  const isLoggedIn = false
  if (isLoggedIn) {
    redirect("/dashboard")
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="light">
      <main className="flex min-h-screen flex-col items-center justify-center p-4 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
        <div className="w-full max-w-md">
          <LoginForm />
        </div>
      </main>
    </ThemeProvider>
  )
}

