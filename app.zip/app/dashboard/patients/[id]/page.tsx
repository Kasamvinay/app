"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, FileText, ClipboardList, Activity, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { PatientSummary } from "@/components/dashboard/patient-summary"
import { PrescriptionForm } from "@/components/dashboard/prescription-form"
import { PatientVitals } from "@/components/dashboard/patient-vitals"

// Sample patient data
const patients = [
  {
    id: 1,
    name: "Sarah Johnson",
    age: 45,
    gender: "Female",
    phone: "(555) 123-4567",
    symptoms: "Chest pain, shortness of breath",
    time: "10:00 AM",
  },
  {
    id: 2,
    name: "Michael Brown",
    age: 62,
    gender: "Male",
    phone: "(555) 234-5678",
    symptoms: "Joint pain, fever",
    time: "11:30 AM",
  },
  {
    id: 3,
    name: "Emily Davis",
    age: 28,
    gender: "Female",
    phone: "(555) 345-6789",
    symptoms: "Migraine, nausea",
    time: "2:15 PM",
  },
]

export default function PatientDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const [patient, setPatient] = useState<any>(null)
  const [activeDialog, setActiveDialog] = useState<"summary" | "prescription" | "vitals" | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would fetch patient data from an API
    const patientId = Number(params.id)
    const foundPatient = patients.find((p) => p.id === patientId)

    if (foundPatient) {
      setPatient(foundPatient)
    } else {
      // Redirect to dashboard if patient not found
      router.push("/dashboard")
    }

    setLoading(false)
  }, [params.id, router])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-green-500"></div>
      </div>
    )
  }

  if (!patient) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back to Dashboard</span>
            </Link>
          </Button>
          <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">Patient Not Found</h1>
        </div>
        <p>The patient you are looking for does not exist.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="outline" size="icon" asChild>
          <Link href="/dashboard">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back to Dashboard</span>
          </Link>
        </Button>
        <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">Patient Details</h1>
      </div>

      <Card className="border-gray-100 dark:border-gray-700 dark:bg-gray-800">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl">{patient.name}</CardTitle>
            <div className="flex items-center gap-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="text-blue-600 dark:text-blue-400 border-blue-200 dark:border-blue-800 hover:bg-blue-50 dark:hover:bg-blue-900/30"
                    onClick={() => setActiveDialog("summary")}
                  >
                    <ClipboardList className="mr-2 h-4 w-4" />
                    Patient Summary
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Patient Summary</DialogTitle>
                    <DialogDescription>Detailed information about {patient.name}</DialogDescription>
                  </DialogHeader>
                  <PatientSummary patient={patient} />
                  <DialogFooter>
                    <Button variant="outline" onClick={() => window.print()} className="flex items-center gap-2">
                      <Printer className="h-4 w-4" />
                      Print Summary
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="text-green-600 dark:text-green-400 border-green-200 dark:border-green-800 hover:bg-green-50 dark:hover:bg-green-900/30"
                    onClick={() => setActiveDialog("prescription")}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    Write Prescription
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-3xl">
                  <DialogHeader>
                    <DialogTitle>Write Prescription</DialogTitle>
                    <DialogDescription>Create a prescription for {patient.name}</DialogDescription>
                  </DialogHeader>
                  <PrescriptionForm patient={patient} />
                </DialogContent>
              </Dialog>

              <Dialog>
                <DialogTrigger asChild>
                  <Button
                    variant="outline"
                    className="text-red-600 dark:text-red-400 border-red-200 dark:border-red-800 hover:bg-red-50 dark:hover:bg-red-900/30"
                    onClick={() => setActiveDialog("vitals")}
                  >
                    <Activity className="mr-2 h-4 w-4" />
                    Patient Vitals
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Patient Vitals</DialogTitle>
                    <DialogDescription>Current vital signs for {patient.name}</DialogDescription>
                  </DialogHeader>
                  <PatientVitals patient={patient} />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Age</p>
                  <p className="text-lg">{patient.age} years</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Gender</p>
                  <p className="text-lg">{patient.gender}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Phone</p>
                  <p className="text-lg">{patient.phone}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Appointment Time</p>
                  <p className="text-lg">{patient.time}</p>
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Symptoms</p>
                <p className="text-lg">{patient.symptoms}</p>
              </div>
            </div>

            <div>
              <PatientVitals patient={patient} />
            </div>
          </div>

          <Tabs defaultValue="history" className="mt-8">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="history">Medical History</TabsTrigger>
              <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
              <TabsTrigger value="lab-results">Lab Results</TabsTrigger>
            </TabsList>

            <TabsContent value="history" className="border rounded-md p-4 dark:border-gray-700">
              <h3 className="text-lg font-medium mb-4">Medical History</h3>
              <div className="space-y-4">
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Annual check-up</h4>
                    <span className="text-sm text-muted-foreground">March 15, 2025</span>
                  </div>
                  <p className="mt-2">Healthy, mild hypertension</p>
                  <p className="text-sm text-muted-foreground mt-1">Dr. Smith</p>
                </div>
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Flu symptoms</h4>
                    <span className="text-sm text-muted-foreground">January 10, 2025</span>
                  </div>
                  <p className="mt-2">Seasonal influenza</p>
                  <p className="text-sm text-muted-foreground mt-1">Dr. Johnson</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="prescriptions" className="border rounded-md p-4 dark:border-gray-700">
              <h3 className="text-lg font-medium mb-4">Prescriptions</h3>
              <div className="space-y-4">
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Amoxicillin</h4>
                    <span className="text-sm text-muted-foreground">March 15, 2025</span>
                  </div>
                  <p className="mt-2">500mg, Three times daily for 7 days</p>
                  <p className="text-sm text-muted-foreground mt-1">Dr. Smith</p>
                </div>
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Ibuprofen</h4>
                    <span className="text-sm text-muted-foreground">January 10, 2025</span>
                  </div>
                  <p className="mt-2">400mg, As needed for pain</p>
                  <p className="text-sm text-muted-foreground mt-1">Dr. Johnson</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="lab-results" className="border rounded-md p-4 dark:border-gray-700">
              <h3 className="text-lg font-medium mb-4">Lab Results</h3>
              <div className="space-y-4">
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Complete Blood Count</h4>
                    <span className="text-sm text-muted-foreground">March 15, 2025</span>
                  </div>
                  <p className="mt-2">Normal</p>
                </div>
                <div className="p-4 border rounded-md dark:border-gray-700">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Blood Pressure</h4>
                    <span className="text-sm text-muted-foreground">March 15, 2025</span>
                  </div>
                  <p className="mt-2">135/85 mmHg (Slightly Elevated)</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

