import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AllPatients } from "@/components/dashboard/all-patients"
import { RecentPatients } from "@/components/dashboard/recent-patients"
import { AllNurses } from "@/components/dashboard/all-nurses"
import { DashboardStats } from "@/components/dashboard/stats"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm border border-gray-100 dark:border-gray-700">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-gray-100">Welcome, Dr. Smith</h1>
        <p className="text-muted-foreground dark:text-gray-400">
          Here's an overview of your patients and appointments for today.
        </p>
      </div>

      <DashboardStats />

      <Tabs defaultValue="all-patients" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="all-patients">All Patients</TabsTrigger>
          <TabsTrigger value="recent-patients">Recent Patients</TabsTrigger>
          <TabsTrigger value="all-nurses">All Nurses</TabsTrigger>
        </TabsList>

        <TabsContent value="all-patients">
          <AllPatients />
        </TabsContent>

        <TabsContent value="recent-patients">
          <RecentPatients />
        </TabsContent>

        <TabsContent value="all-nurses">
          <AllNurses />
        </TabsContent>
      </Tabs>
    </div>
  )
}

